


CREATE TABLE `TBL_PROCESS_CONTROL` (                   
  `APPLICATION_NAME` varchar(255) DEFAULT NULL,        
  `COUNTRY_CD` varchar(255) DEFAULT NULL,              
  `CONFIGURATION_ID` int(11) NOT NULL,                 
  `SOURCE_SYSTEM` varchar(255) NOT NULL,               
  `SUBJECT_AREA` varchar(255) NOT NULL,                
  `SOURCE_TABLE` varchar(255) NOT NULL,                
  `TARGET_WRITE_DB` varchar(255) NOT NULL,             
  `TARGET_TABLE` varchar(255) NOT NULL,                
  `JOB_GROUP_NAME` varchar(255) NOT NULL,              
  `JOB_NAME` varchar(255) DEFAULT NULL,                
  `PARTITION_FLAG` varchar(255) NOT NULL DEFAULT 'N',  
  `INSTANCE_NAME` varchar(255) NOT NULL,               
  `SOURCE_FILE_LOCATION` varchar(255) DEFAULT NULL,    
  `SOURCE_FILE_NAME_PATTERN` varchar(255) DEFAULT NULL,
  `NUM_PART_RETAIN` varchar(20) DEFAULT NULL,          
  `PARTITION_COLUMN` varchar(255) DEFAULT NULL,        
  `REPROCESS_FLAG` varchar(255) NOT NULL DEFAULT 'N',  
  `MOVE_FLAG` varchar(5) NOT NULL DEFAULT 'N',         
  `COLUMN_NUM` decimal(20,0) DEFAULT NULL,             
  `HEADER` varchar(100) DEFAULT NULL,                  
  `FOOTER` varchar(100) DEFAULT NULL,                  
  `DELIMITER` varchar(10) DEFAULT NULL,                
  `MOVE_BY_PART_FLG` varchar(10) NOT NULL DEFAULT 'N', 
  `DROP_PART_FLG` varchar(10) DEFAULT 'N',             
  `INSTANCE_COLUMN` varchar(20) DEFAULT NULL,          
  `DATA_MTH` date DEFAULT NULL,                        
  `SRCE_PUBLISH_DATE` date DEFAULT NULL,               
  `NUM_SRC_MTH` varchar(20) DEFAULT NULL               
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE TBL_CNFG_SPARK (                                    
 `APPLICATION_NAME` varchar(255) DEFAULT NULL, 
 `COUNTRY_CD` varchar(255) DEFAULT NULL,       
 `SOURCE_SYSTEM` varchar(255) DEFAULT NULL,    
 `SUBJECT_AREA` varchar(255) DEFAULT NULL,     
 `SOURCE_TABLE` varchar(255) DEFAULT NULL,     
 `MAIN_CLASS` varchar(255) DEFAULT NULL,       
 `MASTER` varchar(255) DEFAULT NULL,           
 `DRIVER_MEMORY` varchar(255) DEFAULT NULL,    
 `NUM_EXECUTORS` varchar(255) DEFAULT NULL,    
 `EXECUTOR_MEMORY` varchar(255) DEFAULT NULL,  
 `MAXRETRIES` varchar(255) DEFAULT NULL,       
 `SPARK_LOGCONF` varchar(255) DEFAULT NULL,                        
 `SPARK_YARN_DRIVER_MEMORYOVERHEAD` varchar(255) DEFAULT NULL,     
 `SPARK_YARN_EXECUTOR_MEMORYOVERHEAD` varchar(255) DEFAULT NULL,   
 `MYSQL_JAR_PATH` varchar(255) DEFAULT NULL,
 `YARN_QUEUE` varchar(255) DEFAULT NULL,
 `SPARK_APPLICATION_JAR` varchar(255) DEFAULT NULL,                
 `INSERT_DATE` timestamp NULL DEFAULT NULL,                        
 `MODIFIED_DATE` timestamp NULL DEFAULT NULL,                      
 `MODIFIED_BY` varchar(255) DEFAULT NULL,                          
 `ORACLE_JAR_PATH` varchar(255) DEFAULT NULL,                      
 `CUSTOM_CONF` varchar(1000) DEFAULT NULL,                         
 `SHUFFLE_PARTITIONS` varchar(255) DEFAULT NULL,                   
 `EXECUTOR_CORES` varchar(255) DEFAULT NULL                        
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE TBL_CNFG_SPARK (                                                                                                              
`APPLICATION_NAME` varchar(255) DEFAULT NULL,                                                                                              
`COUNTRY_CD` varchar(255) DEFAULT NULL,                                                                                                    
`SOURCE_SYSTEM` varchar(255) DEFAULT NULL,                                                                                                 
`SUBJECT_AREA` varchar(255) DEFAULT NULL,                                                                                                  
`SOURCE_TABLE` varchar(255) DEFAULT NULL,                                                                                                  
`MAIN_CLASS` varchar(255) DEFAULT NULL,                                                                                                    
`MASTER` varchar(255) DEFAULT NULL,                                                                                                        
`DRIVER_MEMORY` varchar(255) DEFAULT NULL,                                                                                                 
`NUM_EXECUTORS` varchar(255) DEFAULT NULL,                                                                                                 
`EXECUTOR_MEMORY` varchar(255) DEFAULT NULL,                                                                                               
`MAXRETRIES` varchar(255) DEFAULT NULL,                                                                                                    
`SPARK_LOGCONF` varchar(255) DEFAULT NULL,                                                                                                 
`SPARK_YARN_DRIVER_MEMORYOVERHEAD` varchar(255) DEFAULT NULL,                                                                              
`SPARK_YARN_EXECUTOR_MEMORYOVERHEAD` varchar(255) DEFAULT NULL,                                                                            
`MYSQL_JAR_PATH` varchar(255) DEFAULT NULL,                                                                                                
`YARN_QUEUE` varchar(255) DEFAULT NULL,                                                                                                    
`SPARK_APPLICATION_JAR` varchar(255) DEFAULT NULL,                                                                                         
`INSERT_DATE` timestamp NULL DEFAULT NULL,                                                                                                 
`MODIFIED_DATE` timestamp NULL DEFAULT NULL,                                                                                               
`MODIFIED_BY` varchar(255) DEFAULT NULL,                                                                                                   
`ORACLE_JAR_PATH` varchar(255) DEFAULT NULL,                                                                                               
`CUSTOM_CONF` varchar(1000) DEFAULT NULL                                                                                                   
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE TBL_EVICO_BRR (                                                                                                           
`APPLICATION_NAME` varchar(255) DEFAULT NULL,                                                                                          
`COUNTRY_CD` varchar(255) DEFAULT NULL,                                                                                                
`brr_grp_key` int(11) DEFAULT NULL,                                                                                                    
`brr_dtl_key` int(11) DEFAULT NULL,                                                                                                    
`brr_src_name` varchar(100) DEFAULT NULL,                                                                                              
`brr_subject_Area` varchar(100) DEFAULT NULL,                                                                                          
`brr_job_group_name` varchar(100) DEFAULT NULL,                                                                                        
`brr_rule_type` varchar(100) DEFAULT NULL,                                                                                             
`brr_rule_sub_type` varchar(100) DEFAULT NULL,                                                                                         
`brr_rule_owner` varchar(100) DEFAULT NULL,                                                                                            
`brr_source_table` varchar(100) DEFAULT NULL,                                                                                          
`brr_dtl_desc` varchar(100) DEFAULT NULL,                                                                                              
`SQL_query` varchar(50535) DEFAULT NULL,                                                                                               
`brr_dtl_lbl_1` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_val_1` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_lbl_2` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_val_2` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_lbl_3` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_val_3` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_lbl_4` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_val_4` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_lbl_5` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_val_5` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_lbl_6` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_val_6` varchar(100) DEFAULT NULL,                                                                                             
`brr_dtl_stat` varchar(100) DEFAULT NULL,                                                                                              
`ins_by_id` varchar(100) DEFAULT NULL,                                                                                                 
`mod_by_id` varchar(100) DEFAULT NULL,                                                                                                 
`ins_date` timestamp NULL DEFAULT NULL,                                                                                                
`last_mod_date` timestamp NULL DEFAULT NULL                                                                                            
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

CREATE TABLE TBL_PROCESS_MASTER (                                                        
`APPLICATION_NAME` varchar(255) DEFAULT NULL,                                            
`COUNTRY_CD` varchar(255) DEFAULT NULL,                                                  
`CONFIGURATION_ID` int(11) NOT NULL,                                                     
`SOURCE_SYSTEM` varchar(255) NOT NULL,                                                   
`SOURCE_TYPE` varchar(255) NOT NULL,                                                     
`SUBJECT_AREA` varchar(255) NOT NULL,                                                    
`SOURCE_TABLE` varchar(255) NOT NULL,                                                    
`TARGET_WRITE_DB` varchar(255) NOT NULL,                                                 
`TARGET_TABLE` varchar(255) NOT NULL,                                                    
`JOB_GROUP_NAME` varchar(255) NOT NULL,                                                  
`JOB_NAME` varchar(255) DEFAULT NULL,                                                    
`PARTITION_FLAG` varchar(20) NOT NULL,                                                   
`PARTITION_SQL` varchar(400) NOT NULL DEFAULT 'NA',                                      
`SOURCE_FILE_LOCATION` varchar(255) DEFAULT NULL,                                        
`SOURCE_FILE_NAME_PATTERN` varchar(255) DEFAULT NULL,                                    
`NUM_PART_RETAIN` varchar(20) DEFAULT NULL,                                              
`PARTITION_COLUMN` varchar(255) DEFAULT NULL,                                            
`MODIFIED_DATE` timestamp NULL DEFAULT NULL,                                             
`INSERT_DATE` timestamp NULL DEFAULT NULL,                                               
`MODIFIED_BY` varchar(255) NOT NULL,                                                     
`ACTIVE_FLAG` varchar(20) NOT NULL,                                                      
`FAILURE_EMAIL_GRP_ID` decimal(10,0) NOT NULL,                                           
`FAILURE_EMAIL_MSG_ID` decimal(10,0) NOT NULL,                                           
`MOVE_FLAG` varchar(5) NOT NULL,                                                         
`COLUMN_NUM` decimal(20,0) DEFAULT NULL,                                                 
`HEADER` varchar(100) DEFAULT NULL,                                                      
`FOOTER` varchar(100) DEFAULT NULL,                                                      
`DELIMITER` varchar(10) DEFAULT NULL,                                                    
`MOVE_BY_PART_FLG` varchar(10) NOT NULL,                                                 
`DROP_PART_FLG` varchar(10) NOT NULL,                                                    
`INSTANCE_COLUMN` varchar(20) DEFAULT NULL,                                              
`NUM_SRC_MTH` varchar(20) DEFAULT NULL,                                                  
`REFRESH_TYPE` varchar(20) DEFAULT NULL,                                                 
`SOURCE_CDC_COLUMN` varchar(1000) DEFAULT NULL,                                          
`NUMBER_OF_LAG_DAYS` int(11) DEFAULT NULL,                                               
`TBL_PRIMARY_KEY` varchar(255) DEFAULT NULL,                                             
PRIMARY KEY (`CONFIGURATION_ID`)                                                         
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE TBL_CNFG_ENVIRONMENT (                                   
`APPLICATION_NAME` varchar(255) DEFAULT NULL,                         
`COUNTRY_CD` varchar(255) DEFAULT NULL,                               
`PARAMATER_NAME` varchar(255) DEFAULT NULL,                           
`PARAMETER_VALUE` varchar(255) DEFAULT NULL,                          
`INSERT_DATE` timestamp NULL DEFAULT NULL,                            
`MODIFIED_DATE` timestamp NULL DEFAULT NULL,                          
`MODIFIED_BY` varchar(255) DEFAULT NULL                               
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE TBL_PROC_JOB_STATUS (                                    
`APPLICATION_NAME` varchar(255) DEFAULT NULL,                         
`COUNTRY_CD` varchar(255) DEFAULT NULL,                               
`RUN_CYCLE_ID` int(11) NOT NULL,                                      
`CONFIGURATION_ID` int(11) NOT NULL,                                  
`SOURCE_SYSTEM` varchar(255) NOT NULL,                                
`SUBJECT_AREA` varchar(255) NOT NULL,                                 
`JOB_NAME` varchar(255) DEFAULT NULL,                                 
`TARGET_TABLE` varchar(255) NOT NULL,                                 
`INSTANCE_NAME` varchar(255) NOT NULL,                                
`START_DATETIME` datetime DEFAULT NULL,                               
`END_DATETIME` datetime DEFAULT NULL,                                 
`STATUS` varchar(255) NOT NULL,                                       
`STEP_NAME` varchar(20) DEFAULT NULL,                                 
`PARENT_SCRIPT_NAME` varchar(255) DEFAULT NULL                        
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE TBL_S3_CONFIGURATION (                                   
`SNO` int(11) NOT NULL AUTO_INCREMENT,                                
`GV_INT` varchar(50) NOT NULL,                                        
`GV_S3_SOURCE` varchar(500) DEFAULT NULL,                             
`GV_NFS_TARGET` varchar(500) DEFAULT NULL,                            
`LAST_SYNC_DATE` varchar(500) DEFAULT NULL,                           
`GV_S3LOC` varchar(500) DEFAULT NULL,                                 
`EMAIL` varchar(500) DEFAULT NULL,                                    
PRIMARY KEY (`SNO`)                                                   
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

CREATE TABLE TBL_FILES_CONFIGURATION (                                  
`GV_INT` varchar(20) NOT NULL DEFAULT '',                               
`GV_ENT` varchar(20) NOT NULL DEFAULT '',                               
`GV_LOCAL_EMAIL_LIST` varchar(500) DEFAULT NULL,                        
`GV_ATTACHMENT_PATH` varchar(50) DEFAULT NULL,                          
`GV_EMAIL_BODY` varchar(50) DEFAULT NULL,                               
`GV_EXT_EMAIL_LIST` varchar(500) DEFAULT NULL,                          
`GV_FTPOUT_EXT_SERVER_ADDR` varchar(50) DEFAULT NULL,                   
`GV_FTPOUT_INT_SERVER_ADDR` varchar(50) DEFAULT NULL,                   
`GV_FTPOUT_SRCE_LOC` varchar(500) DEFAULT NULL,                         
`GV_FTPOUT_DEST_LOC` varchar(500) DEFAULT NULL,                         
`GV_FTPOUT_TGT_SERVER_LOGIN_ID` varchar(20) DEFAULT NULL,               
`GV_FTPOUT_TGT_SERVER_LOGIN_PWD` varchar(20) DEFAULT NULL,              
`GV_FTPOUT_SRCE_FILE_NAME` varchar(1000) DEFAULT NULL,                  
`GV_FTPOUT_TGT_FILE_NM` varchar(50) DEFAULT NULL,                       
`GV_FTPOUT_TGT_FILE_NM_DEL` varchar(50) DEFAULT NULL,                   
`GV_FTPIN_EXT_SERVER_ADDR` varchar(50) DEFAULT NULL,                    
`GV_FTPIN_INT_SERVER_ADDR` varchar(50) DEFAULT NULL,                    
`GV_FTPIN_SRCE_LOC` varchar(500) DEFAULT NULL,                          
`GV_FTPIN_DEST_LOC` varchar(500) DEFAULT NULL,                          
`GV_FTPIN_SRCE_SERVER_LOGIN_ID` varchar(50) DEFAULT NULL,               
`GV_FTPIN_SRCE_SERVER_LOGIN_PWD` varchar(50) DEFAULT NULL,              
`GV_FTPIN_SRCE_FILE_NAME` varchar(500) DEFAULT NULL,                    
`APPLICATIONNAME` varchar(500) DEFAULT NULL,                            
`COUNTRYCODE` varchar(20) DEFAULT NULL,                                 
`HDFSOUTBOUND` varchar(1000) DEFAULT NULL,                              
`HDFSFILENAME` varchar(500) DEFAULT NULL,                               
`NFSOUTBOUNDARCHIVE` varchar(500) DEFAULT NULL,                         
`FTPPORT` varchar(10) DEFAULT NULL,                                     
`NFSINBOUND` varchar(500) DEFAULT NULL,                                 
`NFSARCHIVEPATH` varchar(500) DEFAULT NULL,                             
`HDFSINBOUND` varchar(500) DEFAULT NULL,                                
`TAILOR_FLAG` varchar(2) DEFAULT 'N',                                   
`ZIP_FILE_NM` varchar(500) NOT NULL DEFAULT 'NA',                       
`ZIP_FLAG` char(1) NOT NULL DEFAULT 'N',                                
`GV_DELIMITERS` varchar(100) DEFAULT NULL                               
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE TBL_EXEC_TIME (                                          
`SOURCE_SYSTEM` varchar(255) NOT NULL,                                
`SUBJECT_AREA` varchar(255) NOT NULL,                                 
`STATUS` varchar(255) NOT NULL,                                       
`STEP_NAME` varchar(20) DEFAULT NULL,                                 
`start_datetime` datetime DEFAULT NULL,                               
`end_datetime` datetime DEFAULT NULL,                                 
`EXEC_TIME` time DEFAULT NULL,                                        
`driver_memory` varchar(255) DEFAULT NULL,                            
`num_executors` varchar(255) DEFAULT NULL,                            
`executor_memory` varchar(255) DEFAULT NULL,                          
`spark_yarn_driver_memoryoverhead` varchar(255) DEFAULT NULL,         
`spark_yarn_executor_memoryoverhead` varchar(255) DEFAULT NULL        
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE TBL_PROCESS_DB_TABLE_DELTAPARAMS (                       
`APPLICATION_NAME` varchar(255) DEFAULT NULL,                         
`COUNTRY_CD` varchar(255) DEFAULT NULL,                               
`CONFIGURATION_ID` int(11) DEFAULT NULL,                              
`SOURCE_SYSTEM` varchar(255) DEFAULT NULL,                            
`SUBJECT_AREA` varchar(255) DEFAULT NULL,                             
`SOURCE_TABLE` varchar(255) DEFAULT NULL,                             
`TARGET_TABLE` varchar(255) DEFAULT NULL,                             
`SOURCE_LAST_UPDATED_DATETIME` varchar(255) DEFAULT NULL,             
`INSERT_DATE` timestamp NULL DEFAULT NULL,                            
`UPDATE_DATE` timestamp NULL DEFAULT NULL,                            
`ACTIVE_FLAG` varchar(2) DEFAULT NULL,                                
`CURRENT_RUN_FLAG` varchar(2) DEFAULT NULL,                           
`PREVIOUS_RUN_FLAG` varchar(2) DEFAULT NULL,                          
`SOURCE_TILL_UPDATED_DATETIME` varchar(40) DEFAULT NULL               
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE sequence_data (
APPLICATION_NAME varchar(255) DEFAULT NULL,
 COUNTRY_CD varchar(255) DEFAULT NULL,
  sequence_name varchar(100) NOT NULL,
  sequence_increment int(11) unsigned NOT NULL DEFAULT '1',
  sequence_min_value int(11) unsigned NOT NULL DEFAULT '100',
  sequence_max_value bigint(20) unsigned NOT NULL DEFAULT '18446744073709551615',
  sequence_cur_value bigint(20) unsigned DEFAULT '1000',
  sequence_cycle tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (sequence_name)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


delete from sequence_data;
insert into sequence_data(APPLICATION_NAME,COUNTRY_CD,sequence_name,sequence_increment,sequence_min_value,sequence_max_value,sequence_cur_value,sequence_cycle) values ('ATLAS','US','sq_my_sequence',1,100,18446744073709551615,260000,0);

DROP FUNCTION IF EXISTS nextval;

DELIMITER $$
CREATE FUNCTION `nextval`(seq_name varchar(100)) RETURNS bigint(20)
BEGIN
    DECLARE `cur_val` bigint(20);
    SELECT
        sequence_cur_value INTO cur_val
    FROM
        sequence_data
    WHERE
        sequence_name = seq_name;
    IF cur_val IS NOT NULL THEN
        UPDATE
            sequence_data
        SET
            sequence_cur_value = IF (
                (sequence_cur_value + sequence_increment) > sequence_max_value,
                IF (
                    sequence_cycle = TRUE,
                    sequence_min_value,
                    NULL
                ),
                sequence_cur_value + sequence_increment
            )
        WHERE
            sequence_name = seq_name;
    END IF;
    RETURN cur_val;
END;
$$
DELIMITER ;

Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','LOG_DIR','/var/log/app/proj/all/all/usa/atlas',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','BIN_SCRIPT_DIR','/mnt/share/app/proj/all/all/usa/atlas/project_all_all_atlas/bin',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','PARAM_FILE_DIR','/mnt/share/app/proj/ph/com/usa/atlas/project_all_all_atlas/conf/ParamFiles',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','TEMP_DIR','/mnt/share/app/proj/ph/com/usa/atlas/project_all_all_atlas/tmp',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','SRC_FILE_DIR','/mnt/share/app/proj/ph/com/usa/atlas/project_all_all_atlas/SrcFiles',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','TGT_FILE_DIR','/mnt/share/app/proj/ph/com/usa/atlas/project_all_all_atlas/TgtFiles',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','CONFIG_DIR','/mnt/share/app/proj/ph/com/usa/atlas/project_all_all_atlas/conf',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','ATLAS_PROCESS_CNT','25',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','SRC_LANDING_PATH','/mnt/share/app/proj/ph/com/usa/atlas/project_all_all_atlas/',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','LANDING_HDFS_PATH','/sdata/ph/com/r/ph_com_r_usa_atlas',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','TEMP_PATH','/mnt/share/app/proj/ph/com/usa/atlas/project_all_all_atlas/tmp',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','APPLICATION_NAME','ATLAS',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','COUNTRY_CD','US',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_enrich','/sdata/ph/com/e',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_business','/sdata/ph/com/b',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location','/sdata/ph/com/r',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_roster','/sdata/all/com/r/all_com_r_usa_roster',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_mdm','/sdata/all/all/r/all_all_r_gbl_mdm',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_concerto','/sdata/all/all/r/all_all_r_usa_concerto',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_crmods','/sdata/all/all/b/all_all_b_usa_crmods',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_customer','/sdata/all/all/e/all_all_e_gbl_customer',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_alerts','/sdata/all/all/r/all_all_r_usa_alerts',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_calls','/sdata/all/all/r/all_all_r_usa_calls',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_cdw','/sdata/all/all/r/all_all_r_usa_cdw',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_clinical','/sdata/all/all/r/all_all_r_usa_clinical',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_geodart','/sdata/all/all/r/all_all_r_usa_geodart',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_irma','/sdata/all/all/r/all_all_r_usa_irma',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_suggestions','/sdata/all/all/r/all_all_r_usa_suggestions',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_feedback','/sdata/all/all/r/all_all_r_usa_concerto',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_tot','/sdata/all/all/r/all_all_r_usa_tot',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_vinsights','/sdata/all/all/r/all_all_r_usa_vinsights',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_vntg','/sdata/all/all/r/all_all_r_usa_vntg',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_jams','/sdata/all/com/r/all_com_r_usa_jams/JAMS',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_product','/sdata/all/com/r/all_com_r_usa_product',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_prts','/sdata/all/com/r/all_com_r_usa_prts',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_veeva','/sdata/ph/com/r/ph_com_r_usa_veeva',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_veeva','/sdata/ph/com/u/ph_com_u_gbl_veeva',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','SRC_LANDING_PATH_JAMS','/data/nfsshare/sdata/all/all/r/usa/atlas/JAMS',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','SRC_LANDING_PATH_IRMA','/data/nfsshare/sdata/all/all/r/usa/atlas/IRMA',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','SRC_LANDING_PATH_ALERTS','/data/nfsshare/sdata/all/all/r/usa/atlas/ALERTS',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','SRC_LANDING_PATH_SUGGESTIONS','/data/nfsshare/sdata/all/all/r/usa/atlas/SUGGESTIONS',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','LANDING_HDFS_PATH_JAMS','/data/nfsshare/sdata/all/all/r/usa/atlas/JAMS',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','LANDING_HDFS_PATH_IRMA','/data/nfsshare/sdata/all/all/r/usa/atlas/IRMA',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','LANDING_HDFS_PATH_ALERTS','/data/nfsshare/sdata/all/all/r/usa/atlas/ALERTS',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','LANDING_HDFS_PATH_SUGGESTIONS','/data/nfsshare/sdata/all/all/r/usa/atlas/SUGGESTIONS',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_vdw','/sdata/all/all/r/all_all_r_usa_concerto',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_vdwbkp','/sdata/all/all/r/all_all_r_all_bkp',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_mdmprd','/sdata/all/all/r/all_all_r_usa_concerto',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_ASPNDODS','/sdata/all/all/r/all_all_r_usa_concerto',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_arch','/sdata/all/all/r',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_e2e','/sdata/all/all/r/',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_payors','/sdata/all/all/r/all_all_r_usa_payer',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_midus','/sdata/all/all/r/all_all_r_usa_midus',current_timestamp(),current_timestamp(),'ATLAS');
Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_vdwsup','/sdata/all/all/r/all_all_r_usa_midus',current_timestamp(),current_timestamp(),'ATLAS');