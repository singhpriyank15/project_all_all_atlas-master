use evico_com_meta_db_db2;
delete from TBL_PROCESS_MASTER where application_name = 'ATLAS' and source_system='mdm' and subject_area='mdmodsaddrchainmrg_param';
delete from TBL_CNFG_SPARK where application_name = 'ATLAS' and source_system='mdm' and subject_area='mdmodsaddrchainmrg_param';
delete from TBL_EVICO_BRR where application_name = 'ATLAS' and brr_src_name='mdm' and brr_subject_area='mdmodsaddrchainmrg_param';

Insert into TBL_PROCESS_MASTER (APPLICATION_NAME,COUNTRY_CD,CONFIGURATION_ID,SOURCE_SYSTEM,SOURCE_TYPE,SUBJECT_AREA,SOURCE_TABLE,TARGET_WRITE_DB,TARGET_TABLE,JOB_GROUP_NAME,JOB_NAME,PARTITION_FLAG,PARTITION_SQL,SOURCE_FILE_LOCATION,SOURCE_FILE_NAME_PATTERN,NUM_PART_RETAIN,PARTITION_COLUMN,MODIFIED_DATE,INSERT_DATE,MODIFIED_BY,ACTIVE_FLAG,FAILURE_EMAIL_GRP_ID,FAILURE_EMAIL_MSG_ID,MOVE_FLAG,COLUMN_NUM,HEADER,FOOTER,DELIMITER,MOVE_BY_PART_FLG,DROP_PART_FLG,INSTANCE_COLUMN,NUM_SRC_MTH,REFRESH_TYPE,SOURCE_CDC_COLUMN,NUMBER_OF_LAG_DAYS,TBL_PRIMARY_KEY) values ('ATLAS','US',91994,'mdm','TABLE','mdmodsaddrchainmrg_param','idl_addr_merge_history','all_all_b_usa_crmods','ods_addr_mrg','wf_GENERIC_FILE','m_GENERIC_FILE','N','NA',' ',' ','1','ID',current_timestamp(),current_timestamp(),'ATLAS','Y',1,0,' ',0,'true',' ','NA',' ',' ',' ',' ','null','null',0,null);

Insert into TBL_CNFG_SPARK (APPLICATION_NAME,COUNTRY_CD,SOURCE_SYSTEM,SUBJECT_AREA,SOURCE_TABLE,MAIN_CLASS,MASTER,DRIVER_MEMORY,NUM_EXECUTORS,EXECUTOR_MEMORY,MAXRETRIES,SPARK_LOGCONF,SPARK_YARN_DRIVER_MEMORYOVERHEAD,SPARK_YARN_EXECUTOR_MEMORYOVERHEAD,MYSQL_JAR_PATH,YARN_QUEUE,SPARK_APPLICATION_JAR,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY,ORACLE_JAR_PATH,CUSTOM_CONF,SHUFFLE_PARTITIONS,EXECUTOR_CORES) values ('ATLAS','US','mdm','mdmodsaddrchainmrg_param','idl_addr_merge_history','com.novartis.atlas.brr_engine','yarn','3G','5','10G','15','TRUE','1536','1536','mysql-connector-java-5.1.46.jar','atlas','project_all_all_atlas.jar',current_timestamp(),current_timestamp(),'ATLAS',null,null,'220','4');


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91994,1,'mdm','mdmodsaddrchainmrg_param','atlas_stg_mdm_mdmodsaddrchainmrg_param.sh','Merge_Recursive','NA','ATLAS','idl_addr_merge_history','Load_Data','select distinct  trim(prev_mdm_addr_id) prev_mdm_id ,trim(present_mdm_addr_id) present_mdm_id,merge_date,rec_modify_date from $ALL_ALL_E_GBL_CUSTOMER$.idl_addr_merge_history where rec_modify_date >= CAST(date_sub(CAST(''$LAST_EXECUTED_TIMESTAMP$'' as DATE), 7) AS TIMESTAMP)##/sdata/all/all/b/$ALL_ALL_B_USA_CRMODS$/temp_addr_merge_history','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91994,2,'mdm','mdmodsaddrchainmrg_param','atlas_stg_mdm_mdmodsaddrchainmrg_param.sh','Load_Data','NA','ATLAS','idl_addr_merge_history','Load_Data','insert into $ALL_ALL_B_USA_CRMODS$.error_addr_merge_history select distinct  * from $ALL_ALL_B_USA_CRMODS$.temp_addr_merge_history where rec_modify_date >=  CAST(date_sub(CAST(''$LAST_EXECUTED_TIMESTAMP$'' as DATE), 7) AS TIMESTAMP) and  upper(trim(group_id)) like ''%ERROR%''  ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());




