use evico_com_meta_db_db2;
delete from TBL_PROCESS_MASTER where application_name = 'ATLAS' and source_system='addr' and subject_area='oncconaddrdaily_param';
delete from TBL_CNFG_SPARK where application_name = 'ATLAS' and source_system='addr' and subject_area='oncconaddrdaily_param';
delete from TBL_EVICO_BRR where application_name = 'ATLAS' and brr_src_name='addr' and brr_subject_area='oncconaddrdaily_param';



Insert into TBL_CNFG_SPARK (APPLICATION_NAME,COUNTRY_CD,SOURCE_SYSTEM,SUBJECT_AREA,SOURCE_TABLE,MAIN_CLASS,MASTER,DRIVER_MEMORY,NUM_EXECUTORS,EXECUTOR_MEMORY,MAXRETRIES,SPARK_LOGCONF,SPARK_YARN_DRIVER_MEMORYOVERHEAD,SPARK_YARN_EXECUTOR_MEMORYOVERHEAD,MYSQL_JAR_PATH,YARN_QUEUE,SPARK_APPLICATION_JAR,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY,ORACLE_JAR_PATH,CUSTOM_CONF,SHUFFLE_PARTITIONS,EXECUTOR_CORES) values ('ATLAS','US','addr','oncconaddrdaily_param','ODS_ACCT_ADDR','com.novartis.atlas.brr_engine','yarn','3G','10','10G','15','TRUE','1536','1536','mysql-connector-java-5.1.46.jar','atlas','project_all_all_atlas.jar',current_timestamp(),current_timestamp(),'ATLAS',null,'spark.sql.hive.convertMetastoreParquet=false','200','4');

Insert into TBL_PROCESS_MASTER (APPLICATION_NAME,COUNTRY_CD,CONFIGURATION_ID,SOURCE_SYSTEM,SOURCE_TYPE,SUBJECT_AREA,SOURCE_TABLE,TARGET_WRITE_DB,TARGET_TABLE,JOB_GROUP_NAME,JOB_NAME,PARTITION_FLAG,PARTITION_SQL,SOURCE_FILE_LOCATION,SOURCE_FILE_NAME_PATTERN,NUM_PART_RETAIN,PARTITION_COLUMN,MODIFIED_DATE,INSERT_DATE,MODIFIED_BY,ACTIVE_FLAG,FAILURE_EMAIL_GRP_ID,FAILURE_EMAIL_MSG_ID,MOVE_FLAG,COLUMN_NUM,HEADER,FOOTER,DELIMITER,MOVE_BY_PART_FLG,DROP_PART_FLG,INSTANCE_COLUMN,NUM_SRC_MTH,REFRESH_TYPE,SOURCE_CDC_COLUMN,NUMBER_OF_LAG_DAYS,TBL_PRIMARY_KEY) values ('ATLAS','US',45062,'addr','TABLE','oncconaddrdaily_param','ODS_ACCT_ADDR','$ALL_ALL_B_USA_CRMODS$','MDM_CON_ADDR_DLY_V','wf_GENERIC_FILE','m_GENERIC_FILE','N','NA','','null','0','ID',now(),now(),'','Y',1,1,'Y',0,'true','null','~','N','N','null','null','','',null,null);



Insert into TBL_EVICO_BRR  values ('ATLAS','US',48236,1,'addr','oncconaddrdaily_param','atlas_ods_addr_mdmconaddrdlyv.sh','EXTRACT','NA','ATLAS','ODS_ACCT_ADDR','/sdata/all/all/b/$ALL_ALL_B_USA_CRMODS$/VantageOutbound/~onc_con_addr_daily~NA',"SELECT DISTINCT * FROM $ALL_ALL_B_USA_CRMODS$.MDM_CON_ADDR_DLY_V where substr(trim(addr_per_id),1,3) <> 'ACR'",'NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',now(),now());