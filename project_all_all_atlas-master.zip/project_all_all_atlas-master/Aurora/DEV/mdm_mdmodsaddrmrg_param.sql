use evico_com_meta_db_db2;
delete from TBL_PROCESS_MASTER where application_name = 'ATLAS' and source_system='mdm' and subject_area='mdmodsaddrmrg_param';
delete from TBL_CNFG_SPARK where application_name = 'ATLAS' and source_system='mdm' and subject_area='mdmodsaddrmrg_param';
delete from TBL_EVICO_BRR where application_name = 'ATLAS' and brr_src_name='mdm' and brr_subject_area='mdmodsaddrmrg_param';

Insert into TBL_PROCESS_MASTER (APPLICATION_NAME,COUNTRY_CD,CONFIGURATION_ID,SOURCE_SYSTEM,SOURCE_TYPE,SUBJECT_AREA,SOURCE_TABLE,TARGET_WRITE_DB,TARGET_TABLE,JOB_GROUP_NAME,JOB_NAME,PARTITION_FLAG,PARTITION_SQL,SOURCE_FILE_LOCATION,SOURCE_FILE_NAME_PATTERN,NUM_PART_RETAIN,PARTITION_COLUMN,MODIFIED_DATE,INSERT_DATE,MODIFIED_BY,ACTIVE_FLAG,FAILURE_EMAIL_GRP_ID,FAILURE_EMAIL_MSG_ID,MOVE_FLAG,COLUMN_NUM,HEADER,FOOTER,DELIMITER,MOVE_BY_PART_FLG,DROP_PART_FLG,INSTANCE_COLUMN,NUM_SRC_MTH,REFRESH_TYPE,SOURCE_CDC_COLUMN,NUMBER_OF_LAG_DAYS,TBL_PRIMARY_KEY) values ('ATLAS','US',91993,'mdm','TABLE','mdmodsaddrmrg_param','idl_addr_merge_history','all_all_b_usa_crmods','ods_addr_mrg','wf_GENERIC_FILE','m_GENERIC_FILE','N','NA',' ',' ','1','ID',current_timestamp(),current_timestamp(),'ATLAS','Y',1,0,' ',0,'true',' ','NA',' ',' ',' ',' ','null','null',0,null);

Insert into TBL_CNFG_SPARK (APPLICATION_NAME,COUNTRY_CD,SOURCE_SYSTEM,SUBJECT_AREA,SOURCE_TABLE,MAIN_CLASS,MASTER,DRIVER_MEMORY,NUM_EXECUTORS,EXECUTOR_MEMORY,MAXRETRIES,SPARK_LOGCONF,SPARK_YARN_DRIVER_MEMORYOVERHEAD,SPARK_YARN_EXECUTOR_MEMORYOVERHEAD,MYSQL_JAR_PATH,YARN_QUEUE,SPARK_APPLICATION_JAR,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY,ORACLE_JAR_PATH,CUSTOM_CONF,SHUFFLE_PARTITIONS,EXECUTOR_CORES) values ('ATLAS','US','mdm','mdmodsaddrmrg_param','idl_addr_merge_history','com.novartis.atlas.brr_engine','yarn','3G','5','10G','15','TRUE','1536','1536','mysql-connector-java-5.1.46.jar','atlas','project_all_all_atlas.jar',current_timestamp(),current_timestamp(),'ATLAS',null,null,'220','4');




Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,1,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','DataFrame','NA','ATLAS','idl_addr_merge_history','con_addr',' select distinct contacts_addr_odw_id,contacts_odw_id,mdm_addr_id from $ALL_ALL_B_USA_CRMODS$.ods_contacts_addr where lower(inactive) = ''false''  ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());

Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,2,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','DataFrame','NA','ATLAS','idl_addr_merge_history','con_merge_rec',' select b.contacts_addr_odw_id,b.contacts_odw_id,b.mdm_addr_id,rank() over (partition by contacts_odw_id,mdm_addr_id order by contacts_addr_odw_id ASC ) rnk_cust from (select g2.contacts_addr_odw_id,g1.contacts_odw_id,g1.mdm_addr_id 		from (select contacts_odw_id,mdm_addr_id,count(*)    from con_addr a 				 group by contacts_odw_id,mdm_addr_id having count(*) > 1 ) g1 , 		 con_addr  g2 		where g1.contacts_odw_id=g2.contacts_odw_id and g1.mdm_addr_id = g2.mdm_addr_id)b  ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,3,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','Load_Data','NA','ATLAS','idl_addr_merge_history','Load_Data','insert overwrite table $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG select concat(''CA'',cast(contacts_addr_odw_id as string)) addr_odw_id ,concat(''C'',cast(contacts_odw_id as string)) profile_odw_id,mdm_addr_id, rnk_cust,''CONTACTS'' cust_type,	'''' batch_id_insert, '''' rec_insert_date, '''' rec_insert_by, '''' batch_id_update, '''' rec_modify_date,'''' rec_modify_by  from con_merge_rec ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,4,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','Load_Data','NA','ATLAS','idl_addr_merge_history','Load_Data',' insert overwrite table $ALL_ALL_B_USA_CRMODS$.ods_addr_mrg_temp SELECT  distinct tbl02.addr_odw_id WINNER_ADDR_ODW_ID , tbl03.addr_odw_id LOOSER_ADDR_ODW_ID, tbl01.mdm_addr_id mdm_addr_id , tbl01.cust_type ,$BATCH_ID$ batch_id_insert,current_timestamp rec_insert_date,''MDM'' rec_insert_by, $BATCH_ID$  batch_id_update,current_timestamp rec_modify_Date,''MDM'' rec_modify_by   FROM     $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG tbl01      JOIN  $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG tbl02 ON trim(tbl01.mdm_addr_id) = trim(tbl02.mdm_addr_id)     AND tbl02.rnk_cust = 1      JOIN  $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG tbl03  ON trim(tbl01.mdm_addr_id) = trim(tbl03.mdm_addr_id)     AND tbl03.rnk_cust >= 2 ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());



Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,5,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','DataFrame','NA','ATLAS','idl_addr_merge_history','acct_addr',' select distinct acct_addr_odw_id,acct_odw_id,mdm_addr_id from $ALL_ALL_B_USA_CRMODS$.ods_acct_addr where lower(inactive) = ''false''  ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());

Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,6,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','DataFrame','NA','ATLAS','idl_addr_merge_history','acct_merge_rec',' select b.acct_addr_odw_id,b.acct_odw_id,b.mdm_addr_id,rank() over (partition by acct_odw_id,mdm_addr_id order by acct_addr_odw_id ASC ) rnk_cust from (select g2.acct_addr_odw_id,g1.acct_odw_id,g1.mdm_addr_id 		from (select acct_odw_id,mdm_addr_id,count(*)    from acct_addr a 				 group by acct_odw_id,mdm_addr_id having count(*) > 1 ) g1 , 		acct_addr g2 		where g1.acct_odw_id=g2.acct_odw_id and g1.mdm_addr_id = g2.mdm_addr_id)b ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,7,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','Load_Data','NA','ATLAS','idl_addr_merge_history','Load_Data','insert overwrite table $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG select concat(''AA'',cast(acct_addr_odw_id as string)) addr_odw_id ,concat(''A'',cast(acct_odw_id as string)) profile_odw_id,mdm_addr_id, rnk_cust,''ACCT'' cust_type,	'''' batch_id_insert, '''' rec_insert_date, '''' rec_insert_by, '''' batch_id_update, '''' rec_modify_date,'''' rec_modify_by  from acct_merge_rec ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,8,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','Load_Data','NA','ATLAS','idl_addr_merge_history','Load_Data',' insert into  $ALL_ALL_B_USA_CRMODS$.ods_addr_mrg_temp SELECT  distinct tbl02.addr_odw_id WINNER_ADDR_ODW_ID , tbl03.addr_odw_id LOOSER_ADDR_ODW_ID, tbl01.mdm_addr_id mdm_addr_id , tbl01.cust_type ,$BATCH_ID$ batch_id_insert,current_timestamp rec_insert_date,''MDM'' rec_insert_by, $BATCH_ID$ batch_id_update,current_timestamp rec_modify_Date,''MDM'' rec_modify_by   FROM     $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG tbl01      JOIN  $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG tbl02 ON trim(tbl01.mdm_addr_id) = trim(tbl02.mdm_addr_id)     AND tbl02.rnk_cust = 1      JOIN  $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG tbl03  ON trim(tbl01.mdm_addr_id) = trim(tbl03.mdm_addr_id)     AND tbl03.rnk_cust >= 2 ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());



Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,9,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','DataFrame','NA','ATLAS','idl_addr_merge_history','site_addr',' select distinct site_addr_odw_id,site_odw_id,mdm_addr_id from $ALL_ALL_B_USA_CRMODS$.ods_site_addr where lower(inactive) = ''false'' ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());

Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,10,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','DataFrame','NA','ATLAS','idl_addr_merge_history','site_merge_rec',' select b.site_addr_odw_id,b.site_odw_id,b.mdm_addr_id,rank() over (partition by site_odw_id,mdm_addr_id order by site_addr_odw_id ASC ) rnk_cust from (select g2.site_addr_odw_id,g1.site_odw_id,g1.mdm_addr_id 		from (select site_odw_id,mdm_addr_id,count(*)    from site_addr a 				 group by site_odw_id,mdm_addr_id having count(*) > 1 ) g1 , 		site_addr g2 		where g1.site_odw_id=g2.site_odw_id and g1.mdm_addr_id = g2.mdm_addr_id)b ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,11,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','Load_Data','NA','ATLAS','idl_addr_merge_history','Load_Data',' insert overwrite table $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG select concat(''SA'',cast(site_addr_odw_id as string)) addr_odw_id ,concat(''S'',cast(site_odw_id as string)) profile_odw_id,mdm_addr_id, rnk_cust,''SITE'' cust_type,	'''' batch_id_insert, '''' rec_insert_date, '''' rec_insert_by, '''' batch_id_update, '''' rec_modify_date,'''' rec_modify_by  from site_merge_rec','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,12,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','Load_Data','NA','ATLAS','idl_addr_merge_history','Load_Data',' insert into  $ALL_ALL_B_USA_CRMODS$.ods_addr_mrg_temp SELECT  distinct tbl02.addr_odw_id WINNER_ADDR_ODW_ID , tbl03.addr_odw_id LOOSER_ADDR_ODW_ID, tbl01.mdm_addr_id mdm_addr_id , tbl01.cust_type ,$BATCH_ID$ batch_id_insert,current_timestamp rec_insert_date,''MDM'' rec_insert_by, $BATCH_ID$ batch_id_update,current_timestamp rec_modify_Date,''MDM'' rec_modify_by   FROM     $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG tbl01      JOIN  $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG tbl02 ON trim(tbl01.mdm_addr_id) = trim(tbl02.mdm_addr_id)     AND tbl02.rnk_cust = 1      JOIN  $ALL_ALL_B_USA_CRMODS$.TEMP_ADDR_MRG tbl03  ON trim(tbl01.mdm_addr_id) = trim(tbl03.mdm_addr_id)     AND tbl03.rnk_cust >= 2 ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,13,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','Load_Data','NA','ATLAS','idl_addr_merge_history','Load_Data',' insert into  $ALL_ALL_B_USA_CRMODS$.ods_addr_mrg_temp select * from $ALL_ALL_B_USA_CRMODS$.ods_addr_mrg ods LEFT ANTI JOIN $ALL_ALL_B_USA_CRMODS$.ods_addr_mrg_temp tmp ON ods.WINNER_ADDR_ODW_ID = tmp.WINNER_ADDR_ODW_ID and ods.LOOSER_ADDR_ODW_ID = tmp.LOOSER_ADDR_ODW_ID and ods.mdm_addr_id = tmp.mdm_addr_id','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,14,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','TRUNCATE','NA','ATLAS','idl_addr_merge_history','TRUNCATE',' truncate table $ALL_ALL_B_USA_CRMODS$.ods_addr_mrg ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());


Insert into TBL_EVICO_BRR  values ('ATLAS','US',91993,15,'mdm','mdmodsaddrmrg_param','atlas_stg_mdm_mdmodsaddrmrg_param.sh','Load_Data','NA','ATLAS','idl_addr_merge_history','Load_Data',' insert into  $ALL_ALL_B_USA_CRMODS$.ods_addr_mrg select distinct * from $ALL_ALL_B_USA_CRMODS$.ods_addr_mrg_temp ','NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());












