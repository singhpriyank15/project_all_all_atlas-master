use evico_com_meta_db_db2;
delete from TBL_PROCESS_MASTER where application_name = 'ATLAS' and source_system='addr' and subject_area='oncaddrperdaily_param';
delete from TBL_CNFG_SPARK where application_name = 'ATLAS' and source_system='addr' and subject_area='oncaddrperdaily_param';
delete from TBL_EVICO_BRR where application_name = 'ATLAS' and brr_src_name='addr' and brr_subject_area='oncaddrperdaily_param';



Insert into TBL_CNFG_SPARK (APPLICATION_NAME,COUNTRY_CD,SOURCE_SYSTEM,SUBJECT_AREA,SOURCE_TABLE,MAIN_CLASS,MASTER,DRIVER_MEMORY,NUM_EXECUTORS,EXECUTOR_MEMORY,MAXRETRIES,SPARK_LOGCONF,SPARK_YARN_DRIVER_MEMORYOVERHEAD,SPARK_YARN_EXECUTOR_MEMORYOVERHEAD,MYSQL_JAR_PATH,YARN_QUEUE,SPARK_APPLICATION_JAR,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY,ORACLE_JAR_PATH,CUSTOM_CONF,SHUFFLE_PARTITIONS,EXECUTOR_CORES) values ('ATLAS','US','ADDR','oncaddrperdaily_param','ods_contacts_addr','com.novartis.atlas.brr_engine','yarn','3G','10','10G','15','TRUE','1536','1536','mysql-connector-java-5.1.46.jar','atlas','project_all_all_atlas.jar',current_timestamp(),current_timestamp(),'ATLAS',null,'spark.sql.hive.convertMetastoreParquet=false','200','4');



Insert into TBL_PROCESS_MASTER (APPLICATION_NAME,COUNTRY_CD,CONFIGURATION_ID,SOURCE_SYSTEM,SOURCE_TYPE,SUBJECT_AREA,SOURCE_TABLE,TARGET_WRITE_DB,TARGET_TABLE,JOB_GROUP_NAME,JOB_NAME,PARTITION_FLAG,PARTITION_SQL,SOURCE_FILE_LOCATION,SOURCE_FILE_NAME_PATTERN,NUM_PART_RETAIN,PARTITION_COLUMN,MODIFIED_DATE,INSERT_DATE,MODIFIED_BY,ACTIVE_FLAG,FAILURE_EMAIL_GRP_ID,FAILURE_EMAIL_MSG_ID,MOVE_FLAG,COLUMN_NUM,HEADER,FOOTER,DELIMITER,MOVE_BY_PART_FLG,DROP_PART_FLG,INSTANCE_COLUMN,NUM_SRC_MTH,REFRESH_TYPE,SOURCE_CDC_COLUMN,NUMBER_OF_LAG_DAYS,TBL_PRIMARY_KEY) values ('ATLAS','US',45061,'ADDR','TABLE','oncaddrperdaily_param','ods_contacts_addr','all_all_b_usa_crmods','MDM_ADDR_PER_DLY_V','wf_GENERIC_FILE','m_GENERIC_FILE','N','NA',null,'null','0','ID',current_timestamp(),current_timestamp(),'ATLAS','Y',1,1,'Y',0,'true','null','~','N','N','null','null','null','null',0,null);



Insert into TBL_EVICO_BRR (APPLICATION_NAME,COUNTRY_CD,brr_grp_key,brr_dtl_key,brr_src_name,brr_subject_Area,brr_job_group_name,brr_rule_type,brr_rule_sub_type,brr_rule_owner,brr_source_table,brr_dtl_desc,SQL_query,brr_dtl_lbl_1,brr_dtl_val_1,brr_dtl_lbl_2,brr_dtl_val_2,brr_dtl_lbl_3,brr_dtl_val_3,brr_dtl_lbl_4,brr_dtl_val_4,brr_dtl_lbl_5,brr_dtl_val_5,brr_dtl_lbl_6,brr_dtl_val_6,brr_dtl_stat,ins_by_id,mod_by_id,ins_date,last_mod_date) VALUES ('ATLAS','US',48236,1,'ADDR','oncaddrperdaily_param','atlas_ods_addr_mdmaddrperdlyv.sh','EXTRACT','NA','ATLAS','ods_contacts_addr','/sdata/all/all/b/$ALL_ALL_B_USA_CRMODS$/VantageOutbound/~onc_addr_per_daily~NA',"select distinct ROW_ID as ROW_ID, ADDR as ADDR, ADDR_LINE_2 as ADDR_LINE_2, CITY as CITY, STATE as STATE, ZIPCODE as ZIPCODE,PH_NUM as  PH_NUM,FAX_PH_NUM as FAX_PH_NUM from $ALL_ALL_B_USA_CRMODS$.mdm_addr_per_dly_v where substr(trim(row_id),1,3) <> 'ACR'",'NULL','Null','Null','Null','Null','Null','Null','Null','Null','Null','Null','NULL','Y','Null','Null',current_timestamp(),current_timestamp());

