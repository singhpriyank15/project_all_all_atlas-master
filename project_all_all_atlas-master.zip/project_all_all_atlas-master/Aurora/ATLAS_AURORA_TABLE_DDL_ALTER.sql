


ALTER table TBL_CNFG_SPARK add column  (               
 `SHUFFLE_PARTITIONS` varchar(255) DEFAULT NULL,                   
 `EXECUTOR_CORES` varchar(255) DEFAULT NULL  );

Insert into TBL_CNFG_ENVIRONMENT (APPLICATION_NAME,COUNTRY_CD,PARAMATER_NAME,PARAMETER_VALUE,INSERT_DATE,MODIFIED_DATE,MODIFIED_BY) values ('ATLAS','US','Landing_hive_location_vdwsup','/sdata/all/all/r/all_all_r_usa_midus',current_timestamp(),current_timestamp(),'ATLAS');